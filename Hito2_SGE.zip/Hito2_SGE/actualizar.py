import tkinter as tk
from tkinter import messagebox
import sqlite3
from PIL import Image, ImageTk

class ActualizarItem:
    def __init__(self, root):
        self.root = root
        self.ventana = tk.Toplevel(self.root)
        self.ventana.title("Actualizar Item")
        self.ventana.geometry("400x350")
        self.ventana.configure(bg="#EBEBEB")

        # Cargar la imagen del logo
        imagen_logo = Image.open("logo.png")
        imagen_logo = imagen_logo.resize((200, 80), Image.LANCZOS)
        foto_logo = ImageTk.PhotoImage(imagen_logo)

        # Mostrar la imagen en un Label
        label_logo = tk.Label(self.ventana, image=foto_logo, bg="#EBEBEB")
        label_logo.image = foto_logo
        label_logo.pack(pady=10)

        # Conexión a la base de datos SQLite
        self.conn = sqlite3.connect("productos.db")
        self.c = self.conn.cursor()

        # Variables para almacenar los datos ingresados
        self.id_entry = tk.Entry(self.ventana, font=("Arial", 12))
        self.nuevo_stock_entry = tk.Entry(self.ventana, font=("Arial", 12))

        # Etiquetas y campos de entrada para el formulario de actualización
        self.create_label_entry("ID del Producto:", pady=5, entry=self.id_entry)
        self.create_label_entry("Nuevo Stock:", pady=5, entry=self.nuevo_stock_entry)

        # Botón para procesar la actualización
        btn_actualizar = tk.Button(self.ventana, text="Actualizar", command=self.actualizar_stock, font=("Arial", 14), bg="#aaffaa")
        btn_actualizar.pack(pady=10)

    def create_label_entry(self, label_text, pady, entry):
        tk.Label(self.ventana, text=label_text, bg="#EBEBEB", font=("Arial", 12)).pack(pady=pady)
        entry.pack(pady=pady, padx=10)

    def actualizar_stock(self):
        id_producto = self.id_entry.get()
        nuevo_stock = self.nuevo_stock_entry.get()

        try:
            # Actualizar el stock del producto en la base de datos
            self.c.execute('''
                UPDATE productos
                SET stock = ?
                WHERE id = ?
            ''', (nuevo_stock, id_producto))
            self.conn.commit()

            messagebox.showinfo("Actualizar Stock", "Stock actualizado correctamente.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al actualizar el stock: {e}")

# Esta función es necesaria para ser llamada desde otro archivo
def abrir_ventana_actualizar(root):
    app = ActualizarItem(root)
    root.wait_window(app.ventana)  # Esperar hasta que se cierre la ventana actualizar
