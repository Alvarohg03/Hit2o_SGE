import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import sqlite3

class VisualizarGrafico:
    def __init__(self, root):
        self.root = root
        self.root.title("Visualizar Gráfico")
        self.root.geometry("900x700")

        # Conexión a la base de datos SQLite
        self.conn = sqlite3.connect("productos.db")
        self.c = self.conn.cursor()

        # Obtener datos de la base de datos
        productos = self.obtener_productos()

        # Crear el gráfico
        self.figura, self.ax = Figure(figsize=(5, 4), dpi=100), None
        self.canvas = FigureCanvasTkAgg(self.figura, master=root)
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

        # Inicializar el gráfico
        self.actualizar_grafico()

    def obtener_productos(self):
        self.c.execute('SELECT nombre, stock FROM productos')
        productos = self.c.fetchall()
        return productos

    def actualizar_grafico(self):
        # Limpiar el gráfico antes de actualizar
        if self.ax is not None:
            self.ax.clear()

        # Obtener datos actualizados
        productos = self.obtener_productos()
        nombres_productos, stocks = zip(*productos)

        # Crear un nuevo gráfico de barras
        self.ax = self.figura.add_subplot(111)
        self.ax.bar(nombres_productos, stocks, color='blue')
        self.ax.set_xlabel('Productos')
        self.ax.set_ylabel('Stock')
        self.ax.set_title('Stock de Productos')

        # Actualizar el gráfico en la interfaz
        self.canvas.draw()

if __name__ == "__main__":
    root = tk.Tk()
    app = VisualizarGrafico(root)
    root.mainloop()