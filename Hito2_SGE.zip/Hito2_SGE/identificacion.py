import tkinter as tk
from tkinter import messagebox
import sqlite3
from PIL import Image, ImageTk

def validar_usuario():
    nombre_usuario = entry_nombre.get()

    if not nombre_usuario:
        messagebox.showerror("Introduce un nombre válido")
    else:
        # Conectar a la base de datos SQLite
        conexion = sqlite3.connect("productos.db")
        cursor = conexion.cursor()

        # Crear tabla si no existe
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT
            )
        ''')

        # Insertar nombre de usuario en la base de datos
        cursor.execute("INSERT INTO usuarios (nombre) VALUES (?)", (nombre_usuario,))
        conexion.commit()

        # Cerrar conexión con la base de datos
        conexion.close()

        messagebox.showinfo("Usuario registrado correctamente")

        # Cerrar la ventana después de registrar al usuario
        ventana.destroy()

# Crear la ventana principal
ventana = tk.Tk()
ventana.title("Identificación de Usuario")

# Cargar la imagen
imagen_logo = Image.open("logo.png")
imagen_logo = imagen_logo.resize((300, 100), Image.LANCZOS)
foto_logo = ImageTk.PhotoImage(imagen_logo)

# Mostrar la imagen en un Label
label_logo = tk.Label(ventana, image=foto_logo, bg="#EBEBEB")
label_logo.image = foto_logo
label_logo.pack(pady=10)

# Crear y colocar widgets en la ventana
label_nombre = tk.Label(ventana, text="Nombre:")
label_nombre.pack(pady=10)

entry_nombre = tk.Entry(ventana)
entry_nombre.pack(pady=10)

boton_registrar = tk.Button(ventana, text="Registrar Usuario", command=validar_usuario)
boton_registrar.pack(pady=20)

# Iniciar el bucle principal de la interfaz gráfica
ventana.mainloop()
