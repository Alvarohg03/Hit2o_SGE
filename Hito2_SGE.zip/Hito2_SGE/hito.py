import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
from añadir import abrir_ventana_añadir
from actualizar import abrir_ventana_actualizar
from eliminar import abrir_ventana_eliminar_producto
from consultar import abrir_ventana_consultar
from cliente import abrir_ventana_añadir_cliente
from grafico import VisualizarGrafico
from exportar import ExportarExcel
from pedidos import abrir_ventana_pedidos
from identificacion import validar_usuario

class MiAplicacion:
    def __init__(self, root):
        self.root = root
        self.root.title("HITO")
        self.root.geometry("600x300")  # Establecer el tamaño de la ventana
        self.root.configure(bg="#EBEBEB")
         
        # Cargar la imagen
        imagen_logo = Image.open("logo.png")
        imagen_logo = imagen_logo.resize((300, 100), Image.LANCZOS)
        foto_logo = ImageTk.PhotoImage(imagen_logo)

        # Mostrar la imagen en un Label
        label_logo = tk.Label(self.root, image=foto_logo, bg="#EBEBEB")
        label_logo.image = foto_logo
        label_logo.pack(pady=10)

        # Frame para los botones Añadir, Actualizar, Eliminar y Consultar
        frame_superior = tk.Frame(root)
        frame_superior.pack(side=tk.TOP, pady=20)

        btn_añadir = tk.Button(frame_superior, text="Añadir Item", command=self.abrir_ventana_añadir, bg="#aaffaa")
        btn_añadir.grid(row=0, column=1, padx=10)

        btn_actualizar = tk.Button(frame_superior, text="Actualizar Item", command=self.abrir_ventana_actualizar, bg="#cccccc")
        btn_actualizar.grid(row=0, column=2, padx=10)

        btn_eliminar = tk.Button(frame_superior, text="Eliminar Item", command=self.abrir_ventana_eliminar_producto, bg="#ffaaaa")
        btn_eliminar.grid(row=0, column=3, padx=10)

        btn_consultar = tk.Button(frame_superior, text="Consultar Tabla", command=self.abrir_ventana_consultar, bg="#aaaaff")
        btn_consultar.grid(row=0, column=4, padx=10)

        

        # Frame para los botones inferiores
        frame_inferior = tk.Frame(root)
        frame_inferior.pack(side=tk.BOTTOM, pady=20)

        btn_añadir_cliente = tk.Button(frame_inferior, text="Añadir Cliente", command=self.abrir_ventana_añadir_cliente, bg="#fdfd96")
        btn_añadir_cliente.pack(side=tk.LEFT, padx=10)

        btn_visualizar_grafico = tk.Button(frame_inferior, text="Visualizar Gráfico", command=self.VisualizarGrafico, bg="#de4343")
        btn_visualizar_grafico.pack(side=tk.RIGHT, padx=10)

        btn_exportar_excel = tk.Button(frame_inferior, text="Exportar a Excel", command=self.ExportarExcel, bg="#fdfd96")
        btn_exportar_excel.pack(side=tk.LEFT, padx=10)

        btn_ventana_pedidos = tk.Button(frame_inferior, text="Añadir pedidos", command=self.abrir_ventana_pedidos, bg="#add8e6")
        btn_ventana_pedidos.pack(side=tk.LEFT, padx=10)

    def abrir_ventana_añadir(self):
        abrir_ventana_añadir(self.root)

    def abrir_ventana_actualizar(self):
        abrir_ventana_actualizar(self.root)

    def abrir_ventana_eliminar_producto(self):
        abrir_ventana_eliminar_producto(self.root)

    def abrir_ventana_consultar(self):
        abrir_ventana_consultar(self.root)

    def abrir_ventana_añadir_cliente(self):
        abrir_ventana_añadir_cliente(self.root)

    def VisualizarGrafico(self):
        VisualizarGrafico(self.root)

    def ExportarExcel(self):
        ExportarExcel(self.root)

    def abrir_ventana_pedidos(self):
        abrir_ventana_pedidos(self.root)

    def ValidarUsuario(self):
        validar_usuario(self.root)

if __name__ == "__main__":
    root = tk.Tk()
    app = MiAplicacion(root)
    root.mainloop()
