import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import sqlite3

class AñadirItem:
    def __init__(self, root):
        self.root = root
        self.ventana = tk.Toplevel(self.root)
        self.ventana.title("Añadir Item")
        self.ventana.geometry("650x450")  # Establecer el tamaño de la ventana
        self.ventana.configure(bg="#EBEBEB")  # Establecer el color de fondo de la aplicación

        # Cargar la imagen
        imagen_logo = Image.open("logo.png")
        imagen_logo = imagen_logo.resize((300, 100), Image.LANCZOS)  # Cambiar 'ANTIALIAS' a 'LANCZOS'
        foto_logo = ImageTk.PhotoImage(imagen_logo)

        # Mostrar la imagen en un Label
        label_logo = tk.Label(self.ventana, image=foto_logo, bg="#EBEBEB")
        label_logo.image = foto_logo
        label_logo.pack(pady=10)

        # Conexión a la base de datos SQLite (se creará si no existe)
        self.conn = sqlite3.connect("productos.db")
        self.c = self.conn.cursor()

        # Crear la tabla de productos si no existe
        self.c.execute('''
            CREATE TABLE IF NOT EXISTS productos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT,
                fecha_caducidad TEXT,
                stock INTEGER,
                precio REAL
            )
        ''')
        self.conn.commit()

        # Marco para el formulario
        frame_titulo = tk.Frame(self.ventana, bg="#EBEBEB")
        frame_titulo.pack(pady=20)

        frame_formulario = tk.Frame(self.ventana, bg="#EBEBEB")
        frame_formulario.pack(pady=20)
        tk.Label(frame_titulo, text="AÑADIR PRODUCTOS:", bg="#EBEBEB", font=("Arial", 14), fg="#008f39", anchor="w").pack(pady=5, padx=10, anchor="w")
        # Etiquetas y campos de entrada para el formulario
        tk.Label(frame_formulario, text="Nombre:", bg="#EBEBEB", font=("Arial", 12)).grid(row=0, column=0, padx=10, pady=5)
        self.nombre_entry = tk.Entry(frame_formulario, font=("Arial", 12))
        self.nombre_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(frame_formulario, text="Fecha de Caducidad:", bg="#EBEBEB", font=("Arial", 12)).grid(row=1, column=0, padx=10, pady=5)
        self.fecha_caducidad_entry = tk.Entry(frame_formulario, font=("Arial", 12))
        self.fecha_caducidad_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(frame_formulario, text="Stock:", bg="#EBEBEB", font=("Arial", 12)).grid(row=2, column=0, padx=10, pady=5)
        self.stock_entry = tk.Entry(frame_formulario, font=("Arial", 12))
        self.stock_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(frame_formulario, text="Precio:", bg="#EBEBEB", font=("Arial", 12)).grid(row=3, column=0, padx=10, pady=5)
        self.precio_entry = tk.Entry(frame_formulario, font=("Arial", 12))
        self.precio_entry.grid(row=3, column=1, padx=10, pady=5)

        # Botón para procesar el formulario
        btn_guardar = tk.Button(self.ventana, text="Añadir item", command=self.guardar_producto, bg="#aaffaa", font=("Arial", 14))
        btn_guardar.pack(pady=10)

    def guardar_producto(self):
        nombre = self.nombre_entry.get()
        fecha_caducidad = self.fecha_caducidad_entry.get()
        stock = self.stock_entry.get()
        precio = self.precio_entry.get()

        try:
            # Insertar el producto en la base de datos
            self.c.execute('''
                INSERT INTO productos (nombre, fecha_caducidad, stock, precio)
                VALUES (?, ?, ?, ?)
            ''', (nombre, fecha_caducidad, stock, precio))
            self.conn.commit()

            messagebox.showinfo("Guardar Producto", "Producto guardado correctamente.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al guardar el producto: {e}")

# Esta función es necesaria para ser llamada desde otro archivo
def abrir_ventana_añadir(root):
    app = AñadirItem(root)
    root.wait_window(app.ventana)  # Esperar hasta que se cierre la ventana añadir

# Esto es para ejecutar la ventana de añadir si ejecutas este script directamente
if __name__ == "__main__":
    root = tk.Tk()
    abrir_ventana_añadir(root)
