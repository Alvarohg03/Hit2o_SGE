import tkinter as tk
from tkinter import messagebox
import sqlite3
from PIL import Image, ImageTk

class EliminarProducto:
    def __init__(self, root):
        self.root = root
        self.ventana = tk.Toplevel(self.root)
        self.ventana.title("Eliminar Producto")
        self.ventana.geometry("500x300")
        self.ventana.configure(bg="#EBEBEB")

        # Cargar la imagen del logo
        imagen_logo = Image.open("logo.png")
        imagen_logo = imagen_logo.resize((300, 100), Image.LANCZOS)
        foto_logo = ImageTk.PhotoImage(imagen_logo)

        # Mostrar la imagen en un Label
        label_logo = tk.Label(self.ventana, image=foto_logo, bg="#EBEBEB")
        label_logo.image = foto_logo
        label_logo.pack(pady=10)

        # Conexión a la base de datos SQLite
        self.conn = sqlite3.connect("productos.db")
        self.c = self.conn.cursor()

        # Etiqueta y campo de entrada para el ID del producto a eliminar
        tk.Label(self.ventana, text="ELIMINAR PRODUCTO:", bg="#EBEBEB", font=("Arial", 12), fg="#FF0000").pack(pady=5, padx=10, anchor="w")
        tk.Label(self.ventana, text="ID del Producto:", bg="#EBEBEB", font=("Arial", 12)).pack(pady=5)
        self.id_entry = tk.Entry(self.ventana, font=("Arial", 12))
        self.id_entry.pack(pady=5)

        # Botón para eliminar el producto
        btn_eliminar = tk.Button(self.ventana, text="Eliminar", command=self.eliminar_producto, font=("Arial", 14), bg="#ffaaaa")
        btn_eliminar.pack(pady=10)

    def eliminar_producto(self):
        id_producto = self.id_entry.get()

        try:
            # Eliminar el producto de la base de datos
            self.c.execute('''
                DELETE FROM productos
                WHERE id = ?
            ''', (id_producto,))
            self.conn.commit()

            messagebox.showinfo("Eliminar Producto", "Producto eliminado correctamente.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al eliminar el producto: {e}")

# Esta función es necesaria para ser llamada desde otro archivo
def abrir_ventana_eliminar_producto(root):
    app = EliminarProducto(root)
    root.wait_window(app.ventana)  # Esperar hasta que se cierre la ventana eliminar producto

# Esto es para ejecutar la ventana de eliminar producto si ejecutas este script directamente
if __name__ == "__main__":
    root = tk.Tk()
    abrir_ventana_eliminar_producto(root)
