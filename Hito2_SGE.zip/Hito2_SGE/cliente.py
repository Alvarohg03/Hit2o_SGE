import tkinter as tk
from tkinter import messagebox
import sqlite3
from PIL import Image, ImageTk

class AñadirCliente:
    def __init__(self, root):
        self.root = root
        self.ventana = tk.Toplevel(self.root)
        self.ventana.title("Añadir Cliente")
        self.ventana.geometry("400x300")  # Establecer el tamaño de la ventana
        self.ventana.configure(bg="#EBEBEB")  # Establecer el color de fondo de la aplicación

        # Cargar la imagen del logo
        imagen_logo = Image.open("logo.png")
        imagen_logo = imagen_logo.resize((150, 50), Image.LANCZOS)
        foto_logo = ImageTk.PhotoImage(imagen_logo)

        # Mostrar la imagen en un Label
        label_logo = tk.Label(self.ventana, image=foto_logo, bg="#EBEBEB")
        label_logo.image = foto_logo
        label_logo.pack(pady=10)

        # Conexión a la base de datos SQLite (se creará si no existe)
        self.conn = sqlite3.connect("productos.db")
        self.c = self.conn.cursor()

        # Crear la tabla de clientes si no existe
        self.c.execute('''
            CREATE TABLE IF NOT EXISTS clientes (
                referencia INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT,
                productos_totales INTEGER,
                precio_total Number
            )
        ''')
        self.conn.commit()

        # Marco para el formulario
        frame_formulario = tk.Frame(self.ventana, bg="#EBEBEB")
        frame_formulario.pack(pady=20)

        # Etiquetas y campos de entrada para el formulario
        tk.Label(frame_formulario, text="Nombre del Cliente:", bg="#EBEBEB", font=("Arial", 12)).grid(row=0, column=0, padx=10, pady=5)
        self.nombre_entry = tk.Entry(frame_formulario, font=("Arial", 12))
        self.nombre_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(frame_formulario, text="Productos Totales:", bg="#EBEBEB", font=("Arial", 12)).grid(row=2, column=0, padx=10, pady=5)
        self.productos_totales_entry = tk.Entry(frame_formulario, font=("Arial", 12))
        self.productos_totales_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(frame_formulario, text="Precio Total Gastado:", bg="#EBEBEB", font=("Arial", 12)).grid(row=3, column=0, padx=10, pady=5)
        self.precio_total_entry = tk.Entry(frame_formulario, font=("Arial", 12))
        self.precio_total_entry.grid(row=3, column=1, padx=10, pady=5)

        # Botón para procesar el formulario
        btn_guardar = tk.Button(self.ventana, text="Añadir Cliente", command=self.guardar_cliente, bg="#fdfd96", font=("Arial", 14))
        btn_guardar.pack(pady=10)

    def guardar_cliente(self):
        nombre = self.nombre_entry.get()
        productos_totales = self.productos_totales_entry.get()
        precio_total = self.precio_total_entry.get()

        try:
            # Insertar el cliente en la base de datos
            self.c.execute('''
                INSERT INTO clientes (nombre, productos_totales, precio_total)
                VALUES (?, ?, ?)
            ''', (nombre, productos_totales, precio_total))
            self.conn.commit()

            messagebox.showinfo("Guardar Cliente", "Cliente guardado correctamente.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al guardar el cliente: {e}")

# Esta función es necesaria para ser llamada desde otro archivo
def abrir_ventana_añadir_cliente(root):
    app = AñadirCliente(root)
    root.wait_window(app.ventana)  # Esperar hasta que se cierre la ventana añadir cliente

# Esto es para ejecutar la ventana de añadir cliente si ejecutas este script directamente
if __name__ == "__main__":
    root = tk.Tk()
    abrir_ventana_añadir_cliente(root)
