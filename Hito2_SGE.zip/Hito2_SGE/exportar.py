import tkinter as tk
from tkinter import filedialog
from tkinter import ttk
from openpyxl import Workbook
from openpyxl.styles import Alignment
import sqlite3

class ExportarExcel:
    def __init__(self, root):
        self.root = root
        self.ventana_exportar = tk.Toplevel(self.root)
        self.ventana_exportar.title("Exportar a Excel")
        self.ventana_exportar.geometry("300x150")
        self.ventana_exportar.configure(bg="#EBEBEB")

        # Etiqueta y menú desplegable para seleccionar la tabla
        tk.Label(self.ventana_exportar, text="Seleccionar Tabla:", bg="#EBEBEB", font=("Arial", 12)).pack(pady=10)

        # Cambia la lista de tablas según tus necesidades
        tablas_disponibles = ["productos", "clientes", "pedidos"]

        self.tabla_seleccionada = tk.StringVar()
        self.tabla_seleccionada.set(tablas_disponibles[0])

        combobox_tablas = ttk.Combobox(self.ventana_exportar, textvariable=self.tabla_seleccionada, values=tablas_disponibles, state="readonly")
        combobox_tablas.pack(pady=10)

        # Botón para exportar
        btn_exportar = tk.Button(self.ventana_exportar, text="Exportar", command=self.exportar_a_excel, bg="#aaffaa", font=("Arial", 14))
        btn_exportar.pack(pady=10)

    def exportar_a_excel(self):
        try:
            # Crear un libro de trabajo y una hoja
            libro = Workbook()
            hoja = libro.active

            # Encabezados de columna
            encabezados = self.obtener_encabezados()  # Obtener encabezados según la tabla seleccionada

            # Añadir encabezados a la hoja
            for col_num, encabezado in enumerate(encabezados, 1):
                hoja.cell(row=1, column=col_num, value=encabezado).alignment = Alignment(horizontal="center")

            # Obtener datos de la base de datos
            datos = self.obtener_datos()  # Obtener datos según la tabla seleccionada

            # Añadir datos a la hoja
            for row_num, fila in enumerate(datos, 2):
                for col_num, valor in enumerate(fila, 1):
                    hoja.cell(row=row_num, column=col_num, value=valor).alignment = Alignment(horizontal="center")

            # Guardar el archivo
            ruta_archivo = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Archivos de Excel", "*.xlsx")])
            if ruta_archivo:
                libro.save(ruta_archivo)
                tk.messagebox.showinfo("Exportar a Excel", "Datos exportados a Excel correctamente.")
                self.ventana_exportar.destroy()
        except Exception as e:
            tk.messagebox.showerror("Error", f"Error al exportar a Excel: {e}")

    def obtener_encabezados(self):
        # Implementa la lógica para obtener los encabezados según la tabla seleccionada
        # En este ejemplo, asumimos que la tabla tiene una columna llamada "nombre"
        if self.tabla_seleccionada.get() == "productos":
            return ["ID", "Nombre", "Fecha de Caducidad", "Stock", "Precio"]
        elif self.tabla_seleccionada.get() == "clientes":
            return ["referencia", "nombre", "productos_totales", "precio_total"]
        elif self.tabla_seleccionada.get() == "pedidos":
            return ["id_usuario", "nombre", "productos_pedidos", "precio_pedido"]
        else:
            return []

    def obtener_datos(self):
        # Implementa la lógica para obtener los datos según la tabla seleccionada
        # En este ejemplo, asumimos que la tabla tiene las mismas columnas que los encabezados
        tabla = self.tabla_seleccionada.get()
        conn = sqlite3.connect("productos.db")  # Ajusta la conexión a tu base de datos
        c = conn.cursor()
        c.execute(f"SELECT * FROM {tabla}")
        datos = c.fetchall()
        conn.close()
        return datos
