import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import sqlite3

class AñadirPedidos:
    def __init__(self, root):
        self.root = root
        self.ventana = tk.Toplevel(self.root)
        self.ventana.title("Añadir Pedido")
        self.ventana.geometry("650x450")  
        self.ventana.configure(bg="#EBEBEB")  

        # Cargar la imagen
        imagen_logo = Image.open("logo.png")
        imagen_logo = imagen_logo.resize((300, 100), Image.LANCZOS)
        foto_logo = ImageTk.PhotoImage(imagen_logo)

        # Mostrar la imagen en un Label
        label_logo = tk.Label(self.ventana, image=foto_logo, bg="#EBEBEB")
        label_logo.image = foto_logo
        label_logo.pack(pady=10)

        # Conexión a la base de datos SQLite
        self.conn = sqlite3.connect("productos.db")
        self.c = self.conn.cursor()

        # Crear la tabla de pedidos si no existe
        self.c.execute('''
            CREATE TABLE IF NOT EXISTS pedidos (
                id_usuario INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT,
                productos_pedidos TEXT,
                precio_pedidos INTEGER
            )
        ''')
        self.conn.commit()

        # Marco para el formulario
        frame_titulo = tk.Frame(self.ventana, bg="#EBEBEB")
        frame_titulo.pack(pady=20)

        frame_formulario = tk.Frame(self.ventana, bg="#EBEBEB")
        frame_formulario.pack(pady=20)
        tk.Label(frame_titulo, text="AÑADIR PEDIDOS:", bg="#EBEBEB", font=("Arial", 14), fg="#008f39", anchor="w").pack(pady=5, padx=10, anchor="w")

        # Etiquetas y campos de entrada para el formulario
        tk.Label(frame_formulario, text="Nombre del cliente", bg="#EBEBEB", font=("Arial", 12)).grid(row=1, column=0, padx=10, pady=5)
        self.nombre = tk.Entry(frame_formulario, font=("Arial", 12))
        self.nombre.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(frame_formulario, text="Productos pedidos:", bg="#EBEBEB", font=("Arial", 12)).grid(row=2, column=0, padx=10, pady=5)
        self.productos_pedidos = tk.Entry(frame_formulario, font=("Arial", 12))
        self.productos_pedidos.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(frame_formulario, text="Precio del pedido:", bg="#EBEBEB", font=("Arial", 12)).grid(row=3, column=0, padx=10, pady=5)
        self.precio_pedidos = tk.Entry(frame_formulario, font=("Arial", 12))
        self.precio_pedidos.grid(row=3, column=1, padx=10, pady=5)

        # Botón para procesar el formulario
        btn_guardar = tk.Button(self.ventana, text="Añadir pedido", command=self.guardar_pedido, bg="#aaffaa", font=("Arial", 14))
        btn_guardar.pack(pady=10)

    def guardar_pedido(self):
        nombre = self.nombre.get()
        productos_pedidos = self.productos_pedidos.get()
        precio_pedidos = self.precio_pedidos.get()

        try:
            # Insertar el pedido en la base de datos
            self.c.execute('''
                INSERT INTO pedidos (nombre, productos_pedidos, precio_pedidos)
                VALUES (?, ?, ?)
            ''', (nombre, productos_pedidos, precio_pedidos))
            self.conn.commit()

            messagebox.showinfo("Guardar Pedido", "Pedido guardado correctamente.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al guardar el pedido: {e}")

# Esta función es necesaria para ser llamada desde otro archivo
def abrir_ventana_pedidos(root):
    app = AñadirPedidos(root)
    root.wait_window(app.ventana)  # Esperar hasta que se cierre la ventana añadir

# Esto es para ejecutar la ventana de añadir si ejecutas este script directamente
if __name__ == "__main__":
    root = tk.Tk()
    abrir_ventana_pedidos(root)
