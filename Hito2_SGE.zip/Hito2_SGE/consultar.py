import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from PIL import Image, ImageTk

class ConsultarTabla:
    def __init__(self, root):
        self.root = root
        self.ventana = tk.Toplevel(self.root)
        self.ventana.title("Consultar Tabla")
        self.ventana.geometry("1000x600")  # Establecer el tamaño de la ventana
        self.ventana.configure(bg="#EBEBEB")  # Establecer el color de fondo de la aplicación

        # Cargar la imagen
        imagen_logo = Image.open("logo.png")
        imagen_logo = imagen_logo.resize((300, 100), Image.LANCZOS)
        foto_logo = ImageTk.PhotoImage(imagen_logo)

        # Mostrar la imagen en un Label
        label_logo = tk.Label(self.ventana, image=foto_logo, bg="#EBEBEB")
        label_logo.image = foto_logo
        label_logo.pack(pady=10)

        # Conexión a la base de datos SQLite
        self.conn = sqlite3.connect("productos.db")
        self.c = self.conn.cursor()

        # Obtener todos los productos de la base de datos
        self.c.execute('SELECT * FROM productos')
        productos = self.c.fetchall()

        # Crear un widget Treeview con estilo para mostrar los productos
        style = ttk.Style()
        style.configure("Treeview.Heading", font=("Arial", 10, "bold"))
        style.configure("Treeview", font=("Arial", 10))

        tree = ttk.Treeview(self.ventana, columns=(1, 2, 3, 4, 5), show="headings", height=15, style="Treeview")
        tree.pack(pady=10)

        # Configurar encabezados de columnas
        tree.heading(1, text="ID")
        tree.heading(2, text="Nombre")
        tree.heading(3, text="Fecha de Caducidad")
        tree.heading(4, text="Stock")
        tree.heading(5, text="Precio")

        # Configurar colores alternados
        odd_color = "#D3D3D3"
        even_color = "#A9A9A9"

        # Insertar los productos en el Treeview con colores alternados
        for idx, producto in enumerate(productos, start=1):
            if idx % 2 == 0:
                tree.insert("", tk.END, values=producto, tags=("even",))
            else:
                tree.insert("", tk.END, values=producto, tags=("odd",))

        # Configurar estilos para colores alternados
        style.tag_configure("odd", background=odd_color, foreground="black")
        style.tag_configure("even", background=even_color, foreground="black")

# Esta función es necesaria para ser llamada desde otro archivo
def abrir_ventana_consultar(root):
    app = ConsultarTabla(root)
    root.wait_window(app.ventana)  # Esperar hasta que se cierre la ventana consultar
